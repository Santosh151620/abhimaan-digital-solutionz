﻿export const CompaniesColumns = [];
