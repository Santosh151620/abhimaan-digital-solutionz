﻿export const CompaniesSchema = {};
