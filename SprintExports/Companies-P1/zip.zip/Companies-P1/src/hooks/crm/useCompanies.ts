﻿export function useCompanies() {

    return {};

}
