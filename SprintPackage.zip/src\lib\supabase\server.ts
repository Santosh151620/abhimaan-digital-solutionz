import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";

import { env } from "../env";

export async function createClient() {
  const cookieStore = await cookies();

  return createServerClient(
    env.supabase.url,
    env.supabase.anonKey,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll();
        },

        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(
              ({ name, value, options }) =>
                cookieStore.set(name, value, options)
            );
          } catch {
            // Cookie writes from Server Components
            // are ignored. Middleware/proxy or Route
            // Handlers will refresh sessions.
          }
        },
      },
    }
  );
}
