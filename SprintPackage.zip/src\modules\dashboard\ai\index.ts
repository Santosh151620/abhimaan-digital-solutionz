export { default as AIInsightsPanel } from "./AIInsightsPanel";
